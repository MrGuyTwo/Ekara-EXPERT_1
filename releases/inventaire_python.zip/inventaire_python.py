'''
Description : Script PYTHON qui fait l'inventaire d'un PC (CPU / memoire / disque) 
Découpé en 4 étapes pour EKARA
Génère un JSON pour EKARA
'''

import os
import psutil
import socket
import json
import time
import random

# Initializes the JSON file for the EKARA result
DATA = {
    "return": 0,
    "message": "",
    "steps": []
}

# Retrieves host and IP information (for Step 1) 
def host_info():
   print("Host Name :", socket.gethostname())
   print("IP Address :", socket.gethostbyname(socket.gethostname()))
   file = open("Host_IP.txt", "w") 
   file.write("Host Name : " + str(socket.gethostname()) + "\n") 
   file.write("HIP Address : " + str(socket.gethostbyname(socket.gethostname())) + "\n")
   file.close()

# Retrieves CPU informations (for Step 2) 
def cpu_info():
   print("Cores CPU :", psutil.cpu_count())
   print("Percent CPU used :", psutil.cpu_percent(interval=1), "%")
   file = open("CPU.txt", "w") 
   file.write("Cores CPU :" + str(psutil.cpu_count()) + "\n") 
   file.write("Percent CPU used :" + str(psutil.cpu_percent(interval=1)) + " %\n") 
   file.close()

# Retrieves Memory informations (for Step 3)
def memory_info():
   memory = psutil.virtual_memory()
   print("Total Memory : ", memory.total / 1024.0**3, " GB")
   print("Free Memory : ", memory.available / 1024.0**3, " GB")
   print("Percent Memory used : ", memory.percent, " %")
   file = open("memory.txt", "w") 
   file.write("Total Memory : "+ str(memory.total / 1024.0**3) + " GB\n") 
   file.write("Free Memory : "+ str(memory.available / 1024.0**3) + " GB\n") 
   file.write("Percent Memory used : "+ str(memory.percent) + " %\n") 
   file.close()

# Retrieves Disk informations (for Step 4)
def disk_info():
   disk = psutil.disk_usage('/')
   print("Total disk space : ", disk.total / 1024.0**3, " GB")
   print("Space disk used : ", disk.used / 1024.0**3, " GB")
   print("percent disk used : ", disk.percent, "%")
   file = open("disk.txt", "w") 
   file.write("Total disk space : " + str(disk.total / 1024.0**3) + " GB\n") 
   file.write("Space disk used : " + str(disk.used / 1024.0**3) + " GB\n")
   file.write("percent disk used : " + str(disk.percent) + " %\n")
   file.close()

random_num = random.randrange(1, 100, 1)
if random_num > 70 :
   status = 0  # 1=OK, 0=Error
else:
   status = 1  # 1=OK, 0=Error

#--------- Step 1 (HOST) -----------------------------------------------
startStep = time.time()
host_info()
endStep = time.time()+random.randrange(80, 100, 5)
elapsTime = int(endStep - startStep)

DATA["steps"]=DATA["steps"]+[{
            "name": "HOST",
            "duration": elapsTime,
            "status": 1, #1=OK, 0=Error
            "metrics": [
                {
                    "name": "duration metric",
                    "value": round((elapsTime * 1000), 2),
                    "type": "DURATION"
                }
            ],
            "diags": [
                {
                    "description": "SOURCECODE",
                    "type": "TXT",
                    "filepath": os.path.join(os.getcwd(), f'Host_IP.txt')
                },
                {
                    "description": "STEPSCREENSHOT",
                    "type": "PNG",
                    "filepath" : os.path.join(os.getcwd(),'screen', f'host.png')
                }
            ],
            "messages": [
                {
                    "level": "INFO",
                    "message": "Hostname collected = " + socket.gethostname()
                },
                {
                    "level": "INFO",
                    "message": "IP address collected = " + socket.gethostbyname(socket.gethostname())
                },
                {
                    "level": "INFO",
                    "message": "Step 1 success."
                }
            ]
        },]

#--------- Step 2 (CPU) ------------------------------------------------
startStep = time.time()
cpu_info()
endStep = time.time()+random.randrange(250, 350, 2)
elapsTime = int(endStep - startStep)

DATA["steps"]=DATA["steps"]+[{
            "name": "CPU",
            "duration": elapsTime,
            "status": 1, #1=OK, 0=Error
            "metrics": [
                {
                    "name": "Cores CPU",
                    "value": str(psutil.cpu_count()),
                    "type": "STRING"
                },
                {
                    "name": "Percent CPU used",
                    "value": str(psutil.cpu_percent(interval=1)) + " %",
                    "type": "STRING"
                }
            ],
            "diags": [
                {
                    "description": "HEADER",
                    "type": "TXT",
                    "filepath": os.path.join(os.getcwd(), f'CPU.txt')
                },
                {
                    "description": "STEPSCREENSHOT",
                    "type": "PNG",
                    "filepath" : os.path.join(os.getcwd(),'screen', f'CPU.png')
                }
            ],
            "messages": [
                {
                    "level": "INFO",
                    "message": "Cores CPU collected = " + str(psutil.cpu_count())
                },
                {
                    "level": "WARNING",
                    "message": "Percent CPU used collected  = " + str(psutil.cpu_percent(interval=1)) + " %"
                },
                {
                    "level": "INFO",
                    "message": "Step 2 in WARNING status."
                }
            ]
        },]

#--------- Step 3 (Memory) ---------------------------------------------
startStep = time.time()
memory_info()
endStep = time.time()+random.randrange(250, 550, 5)
elapsTime = int(endStep - startStep)

DATA["steps"]=DATA["steps"]+[{
            "name": "Memory",
            "duration": elapsTime,
            "status": 1, #1=OK, 0=Error
            "metrics": [
                {
                    "name": "Total Memory",
                    "value": str(round(((psutil.virtual_memory().total) / 1024.0**3),2)) + " GB",
                    "type": "STRING"
                },
                {
                    "name": "Free Memory",
                    "value": str(round(((psutil.virtual_memory().available) / 1024.0**3),2)) + " GB",
                    "type": "STRING"
                },
                {
                    "name": "Percent Memory used",
                    "value": str(round(((psutil.virtual_memory().percent)),2)) + " %",
                    "type": "STRING"
                }
            ],
            "diags": [
                {
                    "description": "SOURCECODE",
                    "type": "TXT",
                    "filepath": os.path.join(os.getcwd(), f'memory.txt')
                },
                {
                    "description": "STEPSCREENSHOT",
                    "type": "PNG",
                    "filepath" : os.path.join(os.getcwd(),'screen', f'MEMORY.png')
                }
            ],
            "messages": [
                {
                    "level": "INFO",
                    "message": "Total Memory collected = " + str(round(((psutil.virtual_memory().total) / 1024.0**3),2)) + " GB"
                },
                {
                    "level": "INFO",
                    "message": "Free Memory collected = " + str(round(((psutil.virtual_memory().available) / 1024.0**3),2)) + " GB"
                },
                {
                    "level": "INFO",
                    "message": "Percent Memory used collected = " + str(round(((psutil.virtual_memory().percent)),2)) + " %"
                },
                {
                    "level": "INFO",
                    "message": "Step 3 success."
                }
            ]
        },]

#--------- Step 4 (Disk) -----------------------------------------------
startStep = time.time() 
disk_info()
endStep = time.time()+random.randrange(100, 350, 5)
elapsTime = int(endStep - startStep)

DATA["steps"]=DATA["steps"]+[{
            "name": "Disk",
            "duration": elapsTime,
            "status": status, #1=OK, 0=Error
            "metrics": [
                {
                    "name": "total disk space",
                    "value": str(round(((psutil.disk_usage('/').total) / 1024.0**3),2)) + " GB",
                    "type": "STRING"
                },
                {
                    "name": "space disk used",
                    "value": str(round(((psutil.disk_usage('/').used) / 1024.0**3),2)) + " GB",
                    "type": "STRING"
                },
                {
                    "name": "percent disk used",
                    "value": str(round((psutil.disk_usage('/').percent),2)) + " %",
                    "type": "STRING"
                }
            ],
            "diags": [
                {
                    "description": "SCREENSHOT",
                    "type": "TXT",
                    "filepath": os.path.join(os.getcwd(), f'disk.txt')
                },
                {
                    "description": "STEPSCREENSHOT",
                    "type": "PNG",
                    "filepath" : os.path.join(os.getcwd(),'screen', f'DISK.png')
                }
            ],
            "messages": [
                {
                    "level": "INFO",
                    "message": "Total disk space collected."
                },
                {
                    "level": "WARNING",
                    "message": "Space disk used collected."
                },
                {
                    "level": "WARNING",
                    "message": "percent disk used collected."
                },
                {
                    "level": "ERROR",
                    "message": "Step 4 failed."
                }
            ]
        },]

#--------- Fin ---------------------------------------------------------
if status == 0:
   message = "Scenario ended in error"
else:
   message = "Scenario successfully completed"

DATA["return"]= status
DATA["message"]= message

# Write data into file
with open('result.json', 'w') as file:
   json.dump(DATA, file, indent=4)
